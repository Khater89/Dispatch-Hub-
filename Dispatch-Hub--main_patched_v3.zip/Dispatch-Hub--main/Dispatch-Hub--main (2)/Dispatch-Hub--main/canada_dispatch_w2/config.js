// Cloud API Base URL (Supabase Edge Functions)
// If you host your own backend, replace this.
window.API_BASE = window.API_BASE || "https://whocxxcqnjhvqmsldbkz.supabase.co/functions/v1";
