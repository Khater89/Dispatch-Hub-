window.CA_W2_TECHS = [
  {
    "tech_id": "12152",
    "name": "Lee Morris",
    "city": "Frederickton",
    "province": "NB",
    "postal": "E3A1G8"
  },
  {
    "tech_id": "13291",
    "name": "Richard Rebutoc",
    "city": "Winnipeg",
    "province": "MB",
    "postal": "R2W1Z4"
  },
  {
    "tech_id": "13188",
    "name": "Brad Enman",
    "city": "Calgary",
    "province": "AB",
    "postal": "T3H0A3"
  },
  {
    "tech_id": "14496",
    "name": "Maher Arshinak",
    "city": "Laval",
    "province": "QC",
    "postal": "H7V1X3"
  },
  {
    "tech_id": "12266",
    "name": "Masood Ganjehi",
    "city": "Thornhill",
    "province": "ON",
    "postal": "L3T7Y6"
  },
  {
    "tech_id": "12162",
    "name": "Jonel Tabuzo",
    "city": "Edmonton",
    "province": "AB",
    "postal": "T5X0B3"
  },
  {
    "tech_id": "13790",
    "name": "Edwin Fabian",
    "city": "Richmond (Vancouver)",
    "province": "BC",
    "postal": "V6X4L3"
  },
  {
    "tech_id": "14215",
    "name": "Michael Aigbokhaode",
    "city": "Scarborough",
    "province": "ON",
    "postal": "M1C1Z7"
  }
];
