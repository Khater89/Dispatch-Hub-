// Cloud API Base URL (Backend)
// Example: window.API_BASE = "https://your-backend.onrender.com";
window.API_BASE = window.API_BASE || "https://whocxxcqnjhvqmsldbkz.supabase.co/functions/v1";
